package homework.ch11_13.p2;

public class WechatTask implements Task {
    public void execute() {
        System.out.println("WechatTask is executed.");
    }
}
