package homework.ch11_13.p2;

/**
 * 任务接口
 *
 * @author crackryan
 */
public interface Task {
    /**
     * 执行具体任务的接口方法
     */
    public abstract void execute();
}
