package homework.ch11_13.p2;

public class ChromeTask implements Task {
    public void execute() {
        System.out.println("ChromeTask is executed.");
    }
}
