package homework.ch11_13.p4;

public interface Iterator {
    public boolean hasNext();

    public Component next();
}
