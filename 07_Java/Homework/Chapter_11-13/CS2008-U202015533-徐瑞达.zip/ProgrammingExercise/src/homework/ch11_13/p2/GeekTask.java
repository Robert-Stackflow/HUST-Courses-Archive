package homework.ch11_13.p2;

public class GeekTask implements Task {
    public void execute() {
        System.out.println("GeekTask is executed.");
    }
}
