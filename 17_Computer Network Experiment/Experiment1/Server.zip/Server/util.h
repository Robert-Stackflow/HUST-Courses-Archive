﻿#ifndef UTIL_H
#define UTIL_H
#include <string>
class Util{
public:
    static const char* getContentType(std::string filename);
    static std::string getFilePath(char* requestUrl);
    static char* getResponse404(std::string filename, int bytes);
    static char* getResponse400(std::string filename, int bytes);
    static char *getResponse200(std::string filename, int bytes);
};

#endif // UTIL_H
