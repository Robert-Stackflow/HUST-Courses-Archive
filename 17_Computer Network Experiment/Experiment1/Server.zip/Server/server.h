﻿#ifndef SERVER_H
#define SERVER_H
#pragma once
#include "socket.h"
#include <string.h>
#pragma warning(disable:4290)
using namespace std;
class Server : public Socket {
private:
    fd_set rfds;
    fd_set wfds;
    bool success=false;
    SOCKET sessionSocket;
    int clientPort=0;
    char* clientIp=0;
    bool first_connetion = true;
private:
    void handle200(char* addr, int port, string filePath, char *recvBuf);
    void handle404(char* addr, int port, string filePath, char *recvBuf);
public:
    Server(const char *ip = NULL,unsigned short int port=5050, int backlog = SOMAXCONN);
    ~Server();
    int start();
    bool close();
    bool isSuccess() const;
};
#endif // TCPSERVER_H
