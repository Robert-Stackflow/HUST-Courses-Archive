﻿#ifndef CONFIG_H
#define CONFIG_H
#include <string>
#include <map>
using namespace std;
class Config
{
public:
    static bool showPacket;
private:
    static int port;
    static char ip[1024];
    static string directory;
    static Config* sinstance;
public:
    static Config& instace();
    static void deleteInstace();
    static int getPort();
    static void setPort(int newPort);
    static char *getIpAddress();
    static string getAddress();
    static void clearIp();
    static void setIp(string newIp);
    static const string &getDirectory();
    static void setDirectory(const string &newDirectory);
    static bool ReadConfig(const std::string& filename);
    static void write(string section, string item, string value);
    static std::string ReadString(const char* section, const char* item, const char* default_value);
    static int ReadInt(const char* section, const char* item, const int& default_value);
    static float ReadFloat(const char* section, const char* item, const float& default_value);
private:
    static bool IsSpace(char c);
    static bool IsCommentChar(char c);
    static void Trim(std::string& str);
    static bool AnalyseLine(const std::string& line, std::string& section, std::string& key, std::string& value);
private:
    static std::map<std::string, std::map<std::string, std::string>> settings_;
};
#endif // CONFIG_H
