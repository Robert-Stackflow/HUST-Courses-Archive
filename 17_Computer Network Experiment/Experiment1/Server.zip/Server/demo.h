﻿#ifndef DEMO_H
#define DEMO_H
class Demo{
public:
    static int TestWSAStartUp();
    static void TestSocket();
    static void TestBind();
    static void TestAccept();
};
#endif // DEMO_H
