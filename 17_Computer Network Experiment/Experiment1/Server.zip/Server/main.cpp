#include "server.h"
#include "config.h"
#include <conio.h>
#include <windows.h>
#include <thread>
#include <vector>
#include <regex>
#include <io.h>
#define _CRT_SECURE_NO_WARNINGS
void run();
void finish();
void initConfig();
void editConfig();
bool isRunning = false;
Server* server = nullptr;
int main()
{
	cout << "Server Application Running..." << endl;
	initConfig();
	int op = 1;
	isRunning = false;
	while (op) {
		system("cls");
		if (!isRunning) {
			printf("                         Server                             \n");
			printf("------------------------------------------------------------\n");
			printf("    	  1. Start        2. Stop            3. Restart     \n");
			printf("    	  4. Config       5. Edit Config     0. Exit        \n");
			printf("------------------------------------------------------------\n");
			printf("Input Your Option[0~5]:");
			int flag = scanf("%d", &op);
			switch (op)
			{
			case 1:
				if (!isRunning) {
					thread trun(run);
					trun.detach();
					Sleep(500);
				}
				break;
			case 2:
				finish();
				break;
			case 3:
				if (isRunning) {
					finish();
				} {
					thread trun(run);
					trun.detach();
					Sleep(500);
				}
				break;
			case 4:
				initConfig();
				cout << "Current Config:[IP]" << Config::getIpAddress() << ",[Port]:" << Config::getPort() << ",[Directory]:" << Config::getDirectory() << endl;
				system("pause");
				break;
			case 5:
				editConfig();
				break;
			}
		}
		else {
			printf("                    Server is Running                       \n");
			printf("------------------------------------------------------------\n");
			printf("    	  1. Stop         2. Restart         3. Config      \n");
			printf("------------------------------------------------------------\n");
			printf("Input Your Option[1~3]:");
			int flag = scanf("%d", &op);
			switch (op)
			{
			case 1:
				finish();
				break;
			case 2:
				if (isRunning) {
					finish();
				} {
					thread trun(run);
					trun.detach();
					Sleep(500);
				}
				break;
			case 3:
				cout << "Current Config:[IP]" << Config::getIpAddress() << ",[Port]:" << Config::getPort() << ",[Directory]:" << Config::getDirectory() << endl;
				system("pause");
				break;
			}
		}
	}
	return 0;
}
void run() {
	initConfig();
	server = new Server(Config::getIpAddress(), Config::getPort(), 5);
	if (server->isSuccess())
		isRunning = true, server->start();
	else
		isRunning = false;
}
void finish() {
	if (server != nullptr)
		server->close();
	isRunning = false;
}
void initConfig()
{
	FILE* fp = nullptr;
	fopen_s(&fp, "./config.ini", "r");
	if (fp != nullptr)
	{
		Config::ReadConfig("./config.ini");
		Config::setPort(Config::ReadInt("config", "port", 5050));
		Config::setIp(Config::ReadString("config", "ip", "127.0.0.1"));
		Config::setDirectory(Config::ReadString("config", "directory", "D:/Server"));
		fclose(fp);
	}
}
void editConfig()
{
	int op = 1;
	isRunning = false;
	while (op) {
		system("cls");
		printf("                     Edit Server Config                     \n");
		printf("------------------------------------------------------------\n");
		printf("   1. Show/Hide Packet        2. Edit IP                    \n");
		printf("   3. Edit port               4. Edit Directory             \n");
		printf("   0. Exit                                                  \n");
		printf("------------------------------------------------------------\n");
		printf("Input Your Option[0~5]:");
		int flag = scanf("%d", &op);
		bool ret = false;
		switch (op)
		{
		case 0:
			return;
		case 1:
			ret = false;
			while (!ret) {
				printf("Show(y) or Hide(n) Packet:");
				char ch;
				cin >> ch;
				if (ch == 'y')
					Config::showPacket = true, ret = true;
				else if (ch == 'n')
					Config::showPacket = false, ret = true;
				else
					printf("Input is invalid\n");
			}
			break;
		case 2:
			printf("Current IP:%s\n", Config::getIpAddress());
			ret = false;
			while (!ret) {
				printf("Input new IP or input \"CANCEL\" to cancel:");
				string str;
				cin >> str;
				if (str == "CANCEL")
					break;
				regex ip_reg("^((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})(\\.((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})){3}$");
				ret = std::regex_match(str, ip_reg);
				if (!ret)
					cout << "The IP " << str << " is invalid." << endl;
				else
					Config::setIp(str), Config::write("config", "ip", str);
			}
			break;
		case 3:
			printf("Current Port:%d\n", Config::getPort());
			ret = false;
			while (!ret) {
				printf("Input new port or input \"0\" to cancel:");
				int newPort;
				cin >> newPort;
				if (newPort == 0)
					break;
				regex port_reg("^([0-9]|[1-9]\\d{1,3}|[1-5]\\d{4}|6[0-4]\\d{3}|65[0-4]\\d{2}|655[0-2]\\d|6553[0-5])$");
				ret = std::regex_match(std::to_string(newPort), port_reg);
				if (!ret)
					cout << "The Port " << newPort << " is invalid." << endl;
				else
					Config::setPort(newPort), Config::write("config", "port", to_string(newPort));
			}
			break;
		case 4:
			printf("Current Directory:%s\n", Config::getDirectory().c_str());
			ret = true;
			while (ret) {
				printf("Input new directory or input \"CANCEL\" to cancel:");
				string str;
				cin >> str;
				if (str == "CANCEL")
					break;
				ret = _access(str.c_str(), 0);
				if (ret)
					cout << "The Directory " << str << " is not exist." << endl;
				else
					Config::setDirectory(str), Config::write("config", "directory", str);
			}
			break;
		}
	}
}