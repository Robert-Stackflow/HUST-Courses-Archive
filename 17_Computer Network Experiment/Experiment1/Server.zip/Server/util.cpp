﻿#include <cstring>
#include "parser.h"
#include "util.h"
using namespace std;
#pragma warning(disable:4100)
#pragma warning(disable:6387)
int endsWith(string s, string sub) {
    return s.rfind(sub) == (s.length() - sub.length()) ? 1 : 0;
}
const char* Util::getContentType(std::string filename)
{
    if(endsWith(filename,".html"))
        return "text/html;charset=UTF-8";
    else if(endsWith(filename,".c")||endsWith(filename,".cpp")||endsWith(filename,".md"))
        return "text/plain;charset=UTF-8";
    else if(endsWith(filename,".xml"))
        return "application/xml";
    else if(endsWith(filename,".png"))
        return "image/png";
    else if(endsWith(filename,".jpg"))
        return "image/jpeg";
    else if(endsWith(filename,".jpeg"))
        return "image/jpeg";
    else if(endsWith(filename,".gif"))
        return "image/gif";
    else if(endsWith(filename,".pdf"))
        return "application/pdf";
    else if(endsWith(filename,".doc"))
        return "application/msword";
    else if(endsWith(filename,".ico"))
        return "image/x-icon";
    else if(endsWith(filename,".mp3"))
        return "audio/mp3";
    else if(endsWith(filename,".sql"))
        return "text/plain;charset=UTF-8";
    else if(endsWith(filename,".exe"))
        return "application/x-msdownload";
    return nullptr;
}
std::string Util::getFilePath(char* requestUrl)
{
    HttpParser httpPackage(requestUrl);
    std::string filePath=httpPackage["path"];
    if(filePath=="/"||filePath=="")
        return "/index.html";
    return httpPackage["path"];
}
char* Util::getResponse200(std::string filename, int bytes)
{
    char* str=(char*)malloc(1024*sizeof(char));
    sprintf_s(str,1024,"HTTP/1.1 200 OK \r\nServer:Socket Server\r\nAccept-Ranges:bytes\r\nContent-Length:%d\r\nConnection:keep-alive\r\nContent-Type:%s\r\n\r\n",bytes,getContentType(filename));
    return str;
}
char* Util::getResponse404(std::string filename, int bytes)
{
    char* str = (char*)malloc(1024 * sizeof(char));
    sprintf_s(str,1024,"HTTP/1.1 404 NOT FOUND \r\nServer:Socket Server\r\nAccept-Ranges:bytes\r\nContent-Length:%d\r\nConnection:keep-alive\r\nContent-Type:%s\r\n\r\n",bytes,getContentType(filename));
    return str;
}
char* Util::getResponse400(std::string filename, int bytes)
{
    char* str = (char*)malloc(1024 * sizeof(char));
    sprintf_s(str,1024,"HTTP/1.1 400 INVALID \r\nServer:Socket Server\r\nAccept-Ranges:bytes\r\nContent-Length:%d\r\nConnection:keep-alive\r\nContent-Type:%s\r\n\r\n",bytes,getContentType(filename));
    return str;
}
