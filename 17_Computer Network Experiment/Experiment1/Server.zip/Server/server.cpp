﻿#include"server.h"
#include "util.h"
#include "config.h"
#include<fstream>
#include<WinSock2.h>
#include<Ws2tcpip.h>
#include<windows.h>
#include<sys/stat.h>
#define BUFFER_SIZE 1024
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif
#pragma warning(disable:4700)
#pragma warning(disable:4996)
#pragma warning(disable:4267)
#pragma warning(disable:6001)
#pragma warning(disable:26495)
#pragma comment(lib,"ws2_32.lib")
using namespace std;
Server::Server(const char* ip, unsigned short int port, int backlog) :success(false)
{
	if (!startup()) {
		cout << "Socket Create Failed" << endl;
		return;
	}
	if (!bind(ip, port)) {
		cout << "Socket Bind Failed" << endl;
		return;
	}
	if (!listen(backlog)) {
		cout << "Socket Listen Failed" << endl;
		return;
	}
	success = true;
	cout << "Socket Init Succesfully" << endl;
};
int Server::start() {
	int rtn;
	char recvBuf[4096];
	u_long blockMode = 1;
	SOCKADDR_IN clientAddr;
	int addrLen = sizeof(clientAddr);
	if ((rtn = ioctlsocket(socket, FIONBIO, &blockMode) == SOCKET_ERROR)) {
		cout << "ioctlsocket() Failed" << endl;
		return false;
	}
	while (true)
	{
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);
		FD_SET(socket, &rfds);
		if (!first_connetion) {
			if (sessionSocket != INVALID_SOCKET) {
				FD_SET(sessionSocket, &rfds);
				FD_SET(sessionSocket, &wfds);
			}
		}
		int nTotal = select(0, &rfds, &wfds, NULL, NULL);
		if (FD_ISSET(socket, &rfds)) {
			nTotal--;
			sessionSocket = accept(socket, (LPSOCKADDR)&clientAddr, &addrLen);
			clientPort = ntohs(clientAddr.sin_port);
			clientIp = inet_ntoa(clientAddr.sin_addr);
			cout << "Client Request:" << clientIp << ":" << clientPort << endl;
			if (sessionSocket == INVALID_SOCKET) {
				cout << "Create SessionSocket Failed" << endl;
			}
			if ((rtn = ioctlsocket(sessionSocket, FIONBIO, &blockMode) == SOCKET_ERROR)) {
				cout << "ioctlsocket() Failed" << endl;
				return false;
			}
			FD_SET(sessionSocket, &rfds);
			FD_SET(sessionSocket, &wfds);
			first_connetion = false;
		}
		if (nTotal > 0) {
			if (FD_ISSET(sessionSocket, &rfds)) {
				memset(recvBuf, '\0', 4096);
				rtn = recv(sessionSocket, recvBuf, 4096, 0);
				if (Config::showPacket)
					cout << "Capture Request Packet:\n" << recvBuf << endl;
				if (rtn > 0) {
					FILE* fp;
					string relativeFilePath = Util::getFilePath(recvBuf);
					string filePath = Config::getDirectory() + relativeFilePath;
					fopen_s(&fp, filePath.c_str(), "rb");
					if (fp != nullptr)
						handle200(clientIp, clientPort, filePath, recvBuf);
					else
						handle404(clientIp, clientPort, filePath, recvBuf);
				}
				else {
					nTotal--;
					closesocket(sessionSocket);
					sessionSocket = INVALID_SOCKET;
					cout << "Client Closed..." << endl;
				}
			}
		}
	}
	closesocket(socket);
	WSACleanup();
	return 0;
}
void Server::handle404(char* addr, int port, string filePath, char* recvBu)
{
	FILE* fp = nullptr;
	char response404[200];
	char buffer[BUFFER_SIZE];
	string filePath404 = Config::getDirectory() + "/404.html";
	fopen_s(&fp, filePath404.c_str(), "rb");
	if (fp != nullptr)
	{
		struct stat statbuf;
		stat(filePath404.c_str(), &statbuf);
		string str = Util::getResponse404(filePath404, statbuf.st_size);
		strcpy_s(response404, Util::getResponse404(filePath404, statbuf.st_size));
		cout << "File Not Found:" + filePath << endl;
		send(sessionSocket, response404, str.size(), 0);
		memset(buffer, 0, BUFFER_SIZE);
		int length = 0;
		while ((length = fread(buffer, sizeof(char), BUFFER_SIZE, fp)) > 0) {
			if (send(sessionSocket, buffer, length, 0) < 0)
				break;
			memset(buffer, 0, BUFFER_SIZE);
		}
		fclose(fp);
	}
}
void Server::handle200(char* addr, int port, string filePath, char* recvBuf)
{
	FILE* fp = nullptr;
	char response200[200];
	char buffer[BUFFER_SIZE];
	fopen_s(&fp, filePath.c_str(), "rb");
	cout << "File Request:" + filePath << endl;
	if (fp != nullptr)
	{
		struct stat statbuf;
		int ret = stat(filePath.c_str(), &statbuf);
		string str = Util::getResponse200(filePath, statbuf.st_size);
		strcpy_s(response200, Util::getResponse200(filePath, statbuf.st_size));
		send(sessionSocket, response200, str.size(), 0);
		memset(buffer, 0, BUFFER_SIZE);
		int length = 0;
		while ((length = fread(buffer, sizeof(char), BUFFER_SIZE, fp)) > 0)
		{
			if (send(sessionSocket, buffer, length, 0) < 0) {
				fclose(fp);
				return;
			}
			memset(buffer, 0, BUFFER_SIZE);
		}
		fclose(fp);
	}
	cout << "Send File Successfully:" + filePath << endl;
}
bool Server::close() {
	closesocket(socket);
	WSACleanup();
	cout << "Socket Closed" << endl;
	return true;
}
Server::~Server() {
};
bool Server::isSuccess() const
{
	return success;
}
