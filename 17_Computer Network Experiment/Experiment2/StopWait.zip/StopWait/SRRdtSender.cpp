#include "stdafx.h"
#include "Global.h"
#include "SRRdtSender.h"
#include "Util.h"
#include <string>
#pragma warning(disable:26495)
bool SRRdtSender::getWaitingState()
{
	return waitingState;
}
bool SRRdtSender::send(const Message& message)
{
	if (totalPacketCount < WINDOW_LENGTH / 2)
	{
		//���Լ������ͷ���
		if (totalPacketCount == 0)
			for (int i = 0; i < WINDOW_LENGTH / 2; i++)
				this->isReceived[i] = 0;
		//���ͷ���
		Util::print({ "���ͷ����ͱ���:", Util::toString(this->window[this->totalPacketCount]) });
		this->waitingState = false;
		this->window[this->totalPacketCount].acknum = -1;
		this->window[this->totalPacketCount].seqnum = this->nextSendSeqNum;
		this->window[this->totalPacketCount].checksum = 0;
		memcpy(this->window[this->totalPacketCount].payload, message.data, sizeof(message.data));
		this->window[this->totalPacketCount].checksum = pUtils->calculateCheckSum(this->window[this->totalPacketCount]);
		pns->sendToNetworkLayer(RECEIVER, this->window[this->totalPacketCount]);
		//�򿪶�ʱ��
		pns->startTimer(SENDER, Configuration::TIME_OUT, this->window[this->totalPacketCount].seqnum);
		//������Ϣ
		this->totalPacketCount++;
		this->nextSendSeqNum = (this->nextSendSeqNum + 1) % WINDOW_LENGTH;
		if (this->totalPacketCount == WINDOW_LENGTH / 2)
			this->waitingState = true;
		return true;
	}
	else
	{
		this->waitingState = true;
		return false;
	}
}

void SRRdtSender::receive(const Packet& ackPkt)
{
	int checksum = pUtils->calculateCheckSum(ackPkt);
	if (checksum == ackPkt.checksum) {
		int ackPos = 0;//ack��Ӧ�ķ��������
		bool isInside = false;
		for (int i = 0; i < totalPacketCount; i++)
			if (ackPkt.acknum == window[i].seqnum)
				isReceived[i] = 1, ackPos = i, isInside = true;
		if (isInside) {
			Util::print({ "���ͷ��յ������ڷ����ACK:", Util::toString(ackPkt) });
			if (isReceived[0] == 1) {
				//���Ի�������
				pns->stopTimer(SENDER, this->window[0].seqnum);
				//���㻬�����ڳ���
				int righten = 0;
				for (int i = 0; i < WINDOW_LENGTH / 2; i++)
					if (isReceived[i] == 0)
						break;
					else
						righten++;
				Util::print(window, WINDOW_LENGTH, isReceived);
				Util::print({ "�����ڻ���",to_string(righten),"����λ" });
				if (righten != this->totalPacketCount) {
					for (int i = 0; i < totalPacketCount - righten; i++) {
						this->window[i] = this->window[i + righten];
						this->isReceived[i] = this->isReceived[i + righten];
					}
					for (int j = this->totalPacketCount - righten; j < WINDOW_LENGTH / 2; j++)
						isReceived[j] = 0;
				}
				else {
					for (int i = 0; i < WINDOW_LENGTH / 2; i++)
						isReceived[i] = 0;
				}
				this->waitingState = false;
				this->totalPacketCount -= righten;
				this->windowFirstSeqNum = (this->windowFirstSeqNum + righten) % WINDOW_LENGTH;
				Util::print(window, WINDOW_LENGTH, isReceived);
			}
			else {
				pns->stopTimer(SENDER, this->window[ackPos].seqnum);
			}
		}
		else {
			pns->stopTimer(SENDER, ackPkt.acknum);
			Util::print({ "���ͷ��յ����ڴ����ڷ����ACK:", Util::toString(ackPkt) });
		}
	}
}

void SRRdtSender::timeoutHandler(int seqNum)
{
	//���·���seqNum��Ӧ���鼴��
	int pos = 0;
	for (int i = 0; i < totalPacketCount; i++)
		if (seqNum == window[i].seqnum)
			pos = i;
	pns->stopTimer(SENDER, seqNum);
	pns->startTimer(SENDER, Configuration::TIME_OUT, seqNum);
	Util::print({ "���ͷ���ʱ����ʱ�����·��ͱ���:", Util::toString(this->window[pos]) });
	pns->sendToNetworkLayer(RECEIVER, this->window[pos]);
}

SRRdtSender::SRRdtSender() :totalPacketCount(0), waitingState(false), nextSendSeqNum(0), windowFirstSeqNum(0)
{
}

SRRdtSender::~SRRdtSender()
{
}
