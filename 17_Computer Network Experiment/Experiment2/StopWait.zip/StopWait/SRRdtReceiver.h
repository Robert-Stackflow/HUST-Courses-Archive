#ifndef SR_RDT_RECEIVER_H
#define SR_RDT_RECEIVER_H
#define WINDOW_LENGTH 8
#pragma once
#include "RdtReceiver.h"
class SRRdtReceiver :public RdtReceiver
{
private:
	Packet Ack;
	int totalPacketCount;
	int windowFirstSeqNum;
	Packet window[WINDOW_LENGTH / 2];
	bool isReceived[WINDOW_LENGTH / 2];
public:
	SRRdtReceiver();
	virtual ~SRRdtReceiver();

public:
	void receive(const Packet& packet);	//���ձ��ģ�����NetworkService����
};
#endif