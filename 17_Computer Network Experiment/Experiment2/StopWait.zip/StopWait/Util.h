#ifndef UTIL_H
#define UTIL_H
#pragma once
#include "stdafx.h"
#include "DataStructure.h"
class Util
{
public:
	static FILE* fp;
	static const char* filePath;
public:
	Util();
	~Util();
	static string toString(Packet packet);
	static void print(initializer_list<string> il);
	static void print(Packet window[], int LENGTH, int totalCount);
	static void print(Packet window[], int LENGTH, bool isExisted[]);
};
#endif