#include "Util.h"
#include <string>
#include <chrono>
FILE* Util::fp = nullptr;
const char* Util::filePath = "./rdt.log";
Util::Util()
{
}
string Util::toString(Packet packet)
{
	char payload[21];
	strncpy(payload, packet.payload, 20);
	payload[20] = '\0';
	return string("seqnum = " + std::to_string(packet.seqnum) + ",acknum = " + std::to_string(packet.acknum) + ",checknum = " + std::to_string(packet.checksum) + ",payload = " + payload);
}
void Util::print(initializer_list<string> il)
{
	string message;
	for (auto p = il.begin(); p != il.end(); p++)
		message += *p;
	char* str = new char[1024];
	sprintf(str, "%s\n", message.c_str());
	if (str == nullptr)
		return;
	if (fp == nullptr)
		fp = new FILE();
	if (fp != nullptr) {
		fopen_s(&fp, filePath, "a+");
		if (fp != nullptr) {
			fprintf(fp, "%s", str);
			fclose(fp);
		}
	}
	cout << str;
}

void Util::print(Packet window[], int WINDOW_LENGTH, bool isExisted[])
{
	string windowStr = "";
	for (int i = 0; i < WINDOW_LENGTH / 2; i++)
		windowStr += to_string(i), windowStr += "\t";
	windowStr += "\n";
	for (int i = 0; i < WINDOW_LENGTH / 2; i++) {
		if (isExisted[i])
			windowStr += to_string(window[i].seqnum), windowStr += "\t";
		else
			windowStr += '*', windowStr += "\t";
	}
	Util::print({ "��ǰ����Ϊ:\n",windowStr });
}

void Util::print(Packet window[], int WINDOW_LENGTH, int totalCount)
{
	string windowStr = "";
	for (int i = 0; i < WINDOW_LENGTH / 2; i++)
		windowStr += to_string(i), windowStr += "\t";
	windowStr += "\n";
	for (int i = 0; i < WINDOW_LENGTH / 2; i++) {
		if (i < totalCount)
			windowStr += to_string(window[i].seqnum), windowStr += "\t";
		else
			windowStr += '*', windowStr += "\t";
	}
	Util::print({ "��ǰ����Ϊ:\n",windowStr });
}

Util::~Util()
{
	if (fp != nullptr)
		fclose(fp);
}
